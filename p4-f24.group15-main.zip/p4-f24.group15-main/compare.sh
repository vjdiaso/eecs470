


echo "Comparing ground truth outputs to new processor"
    cd $HOME/eecs470/real_fetch_andmemops3
    # This only runs *.s files. How could you add *.c files?
    for source_file in programs/*.c; do
        if [ "$source_file" = "programs/crt.s" ]
        then
        continue
        fi
        program=$(echo "$source_file" | cut -d '.' -f1 | cut -d '/' -f 2)
        echo "Running $program"
        make "$program.out"
        echo "Comparing writeback output for $program"
        diff output/$program.wb $HOME/eecs470/P3/output/$program.wb
        out1=$?
        if [ $out1 -eq 1 ]
        then
            echo -e "\e[31mFAIL\e[0m"
        else
            echo -e "\e[32mPASS\e[0m"
        fi
        echo "Comparing memory output for $program"
        diff <(cat output/$program.out | grep "@@@") <(cat $HOME/eecs470/P3/output/$program.out | grep "@@@")
        out2=$?
        if [ $out2 -eq 1 ]
        then
            echo -e "\e[31mFAIL\e[0m"
        else
            echo -e "\e[32mPASS\e[0m"
        fi
        echo "Printing Passed or Failed"
done